from django.apps import AppConfig


class Account2Config(AppConfig):
    name = 'account2'
